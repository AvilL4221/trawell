Mod by Sildur:
https://www.nexusmods.com/metaphorrefantazio/mods/4

Installation:
1. Download and unzip this mod.
2. Move all the files in to your Metaphor folder, next to the .exe file.
3. Aaaand that's it, enjoy the game!
Note: Pressing "Home" will bring up the reshade menu and allows you to toggle SMAA and TAA individually.

Uninstall:
Delete dxgi.dll, ReShade.ini, and the Reshade folder.
